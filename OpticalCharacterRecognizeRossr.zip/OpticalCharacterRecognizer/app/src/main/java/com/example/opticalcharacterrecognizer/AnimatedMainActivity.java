package com.example.opticalcharacterrecognizer;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class AnimatedMainActivity extends AppCompatActivity {

    public void textRecognizer(View view)
    {
        Intent i=new Intent(getApplicationContext(),TextRecognizer.class); //Get Application context-gives the current context
        startActivity(i);
    }
    public void speechRecognizer(View view)
    {
        Intent i=new Intent(getApplicationContext(),Speech.class);
        startActivity(i);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
//package com.example.opticalcharacterrecognizer;
//
//import android.content.Intent;
//import android.os.Bundle;
//import android.os.Handler;
//
//import androidx.appcompat.app.AppCompatActivity;
//
//public class AnimatedMainActivity extends AppCompatActivity {
//    private static int timeout=4000;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_animated_main);
//        getSupportActionBar().hide();
//        new Handler().postDelayed(new Runnable() {
//           @Override
//            public void run(){
//               Intent i=new Intent(getApplicationContext(),MainActivity.class);
//               startActivity(i);
//               finish();
//           }
//        },timeout);
//    }
//}