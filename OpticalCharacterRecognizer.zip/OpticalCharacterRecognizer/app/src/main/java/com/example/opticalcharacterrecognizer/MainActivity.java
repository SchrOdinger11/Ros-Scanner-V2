package com.example.opticalcharacterrecognizer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    public void textRecognizer(View view)
    {
        Intent i=new Intent(getApplicationContext(),TextRecognizer.class); //Get Application context-gives the current context
        startActivity(i);
    }
    public void speechRecognizer(View view)
    {
        Intent i=new Intent(getApplicationContext(),Speech.class);
        startActivity(i);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}